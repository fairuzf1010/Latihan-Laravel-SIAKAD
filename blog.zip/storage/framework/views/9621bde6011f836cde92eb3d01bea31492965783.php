<?php $__env->startSection('judul'); ?>

<center><h1 class="h3 mb-0 text-gray" style ="text-align:center;font-size:30px;"> Tabel CRUD </h1></center> 


<?php $__env->stopSection(); ?>





<?php $__env->startSection('tabel'); ?>
<div class="col-md-3" style = "margin-bottom:20px;margin-left:80%;">
<a href="/siswa/exportexcel" class="btn btn-primary d-none d-sm-inline-block" >
<i class="fas fa-download fa-sm text-white-50"></i> Export Data Excel
</a>
</div>

<div class="col-md-3" style = "margin-bottom:20px;margin-left:80%;">
<a href="/siswa/exportpdf" class="btn btn-primary d-none d-sm-inline-block" >
<i class="fas fa-download fa-sm text-white-50"></i> Export Data PDF
</a>
</div>



<div class = "container">
<div class = "wrapper">
<table class="table">
  <thead class="thead-dark">
    <tr>
      
      <th scope="col">Nama Siswa</th>
      <th scope="col">Departemen</th>
      <th scope="col">Progres</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>

  <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      
      <td> <?php echo e($siswa->nama); ?></a></td>
      <td> <?php echo e($siswa->jurusan); ?> </td>
      <td> <?php echo e($siswa->progres); ?> </td>
      <td> <a href="/siswa/<?php echo e($siswa->id); ?>/edit" class = "btn btn-warning btn-sm" > edit</a>
           <a href="/siswa/<?php echo e($siswa->id); ?>/delete" class = "btn btn-danger btn-sm delete" siswa-id = "/siswa/<?php echo e($siswa->id); ?>/delete" > delete</a>
           <a href="/siswa/<?php echo e($siswa->id); ?>/profile" class = "btn btn-info btn-sm" > profile</a>
    </td>
   
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


</div>
</div>

<br><br><br> <br> <br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<script>
$('.delete').click(function()
{
  var siswa_id = $(this).attr('siswa-d');
  swal({
  title: "Are you sure?",
  text: "Once deleted, you will not be able to recover this imaginary file!",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
   
   windows.location = "/siswa/<?php echo e($siswa->id); ?>/delete"

  } else {
    swal("Your imaginary file is safe!");
  }
});




})




</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\XAMPP\htdocs\laravel4\blog\resources\views/siswa/index.blade.php ENDPATH**/ ?>