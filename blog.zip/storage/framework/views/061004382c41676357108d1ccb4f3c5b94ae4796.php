<table class="table">
    <thead>
        <tr>
            <th>NAMA LENGKAP</th>
            <th>JURUSAN</th>
            <th>PROGRES</th>
            <th>NILAI</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($a->nama); ?> </td>
            <td> <?php echo e($a->jurusan); ?> </td>
            <td> <?php echo e($a->progres); ?> </td>
            <td> <?php echo e($a->nilai); ?> </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH F:\XAMPP\htdocs\laravel4\blog\resources\views/export/siswapdf.blade.php ENDPATH**/ ?>