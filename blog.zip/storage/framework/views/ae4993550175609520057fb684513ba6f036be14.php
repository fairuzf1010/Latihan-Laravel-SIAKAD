<?php $__env->startSection('beranda'); ?>

<div class = "jumbotron">
<h1> Ayo Daftarkan Dirimu Demi Masa Depanmu ! </h1>
<p>  MechTechPedia merupakan salah satu  Media Sosial yang mempunyai fitur<br> untuk menyimpan gambar 3D dari berbagai aplikasi teknik seperti CAD dan sebagainya, <br> yang dimana bisa anda download </p>
<center><a href="" class = "btn btn-lg btn-dark"> Join Kami</a></center> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\XAMPP\htdocs\laravel4\blog\resources\views/beranda.blade.php ENDPATH**/ ?>