<?php 

include 'koneksi.php'; 

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="js/jquery-1.12.4-jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />


    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="adminlte/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link href="assets/css/custom.css" rel="stylesheet" />
 <link rel="stylesheet" href="gambar/icon-1/css/ionicons.css">
 
  
    <link rel="stylesheet" href="navbar2.css">
    <link rel="stylesheet" href="footer.css">
    <link rel="stylesheet" href="footer1.css">
    










    <title>Halaman-Awal MechTech</title>

   

  </head>
  <body>








  <nav class="navbar navbar-expand-lg navbar-light bg-danger navbar-fixed-top">
  <a class="navbar-brand navbar-light" href="#" style = "color:white; padding-top:0px;" id = "logo">  <img src="gambar/MechTech.jpeg" alt="text/css" style = "display:inline;width:50px; padding-bottom:5px;margin-bottom:10px;">  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" style = "color:white;" href="beranda.php">Beranda &nbsp; <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" style = "color:white;" href="#">Profil MechTech &nbsp;  </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" style = "color:white;" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Member Area
          &nbsp; 
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="adminregisterationdua.php" style = "color:red;">Sign Up</a>
          <a class="dropdown-item" href="logindua.php" style = "color:red;">Login</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#" style = "color:red;">dan lainnya</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#" style = "color:white;" tabindex="-1" aria-disabled="true"><div id="MyClockDisplay"  style = " 
    
   color:white;
    " class="clock" onload="showTime()"></div> 



</div>
</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>




<br><br><br>











<center>
<div class="jumbotron" style = " min-height:300px;background-size:cover;background-image:url(gambar/Mesin1.png)">
<div class = "row">

<div class = "col-lg-12"><br><br></h1></div>


<div class ="col-sm-1" >
<br>
<div class = "nav-item" style = "size:50px;">


</div>
</div>








<div class = "col-lg-5">
    
<iframe  width="420" height="345" frameBorder = "none" src=" https://www.youtube.com/embed/FurC2unHeXI">
</iframe>

    </div>






     <div class = "col-lg-5">
    
         <h2 style = "text-align:left; color:white; font-size:40px;"> Jutaan Pekerjaan Manusia akan Digantikan Robot</h2> <br> <br><br>
        <p style = "text-align:left; color:white;font-weight:5px;"> <strong>Sudahkah kamu mempersiapkannya? Skill apa yang bisa kamu jual melawan robot? Segera persiapkan mulai dari sekarang bersama kami.  MechTech membuka kelas untuk menambah skillmu menguasai software teknik.</strong></p>
        <a href="adminregisterationdua.php" class = "btn btn-primary btn-lg" style = "font-size:20px;"> <strong>Lihat Kelas</strong></a>
    </div>






    <div></div>


<div class = "col-md-4">
<br><br>
<br><br>




</div>

<br>
  

</div>
</center>
















<center>
<div class="jumbotron" style = " min-height:600px;background-size:cover;background-color:white;">
<div class = "row">

<div class = "col-lg-12"><br><br></h1></div>


<div class ="col-sm-1" >
<br>
<div class = "nav-item" style = "size:50px;">

<div class = "fa fa-cog fa-4x" style = "size:50px;"></div>
</div>



</div>




     <div class = "col-lg-5">
    
         <h2 style = "text-align:left; color:black; font-size:40px;"> Apakah Kamu Mahasiswa Teknik ? </h2> <br> <br><br>
        <p style = "text-align:left;">Untuk dapat bersaing dengan kompetitor, kamu harus mempersiapkan kelebihanmu. Menguasai software CAD dan software engineer lainnya akan menjadi nilai plus saat kamu duduk di bangku kuliah atau masuk di dunia kerja. Software engineer menjadi salah satu pekerjaan yang tidak bisa digantikan oleh robot di masa mendatang.</p>
    
    </div>




    <div class = "col-lg-5">
    
    <img src="gambar/dikretisasi.png" alt="text/css">
    
    
    
    
    
    
    
    
    </div>







    <div></div>


<div class = "col-md-4">
<br><br>
<br><br>




</div>

<br>
  

</div>
</center>






















<div class = "jumbotron" style = "background-color:silver; min-height:700px;">

<center> <h2 style = "font-size:50px; color:black;">Profil Tutor</h2></center> 
m
<div class = "row" style = "margin-left:50px; padding-top:50px;" >




<div class ="col-sm-1" >
<br>

</div>












<center>

<div class = "col-md-2" style = "margin-left:10px;margin-right:50px;" >
<div class = "card" style = "padding-bottom:5px;height:500px; width:300px;">
<div class = "caption" style = "padding-left : 10px; padding-right:10px;">
<img src="assets/img/find_user.png" alt="text/css">
<h5 style = "font-size:25px; margin-top:5px;" > <strong> <center>M Hasbi Akbar</center> </strong>  </h5>
<h6 style = "font-size:20px; margin-top:10px; margin-bottom:4px;color:red;"> <center>Solidworks</center> </h6>
<h7 style = "font-size:15px;"> <center>Telah menggunakan SolidWorks sejak awal menjadi mahasiswa, dengan ketekunan dan kreatifitas membawanya menjadi juara di berbagai perlombaan di bidang robot. Salah satunya desain robot terbaik.</center> </h7>
<br>
<center><a style= "margin-bottom:5px;" href="ambil.php?id=<?php echo $bagian['id_program'] ?>" class = "btn btn-success btn-lg" name = "programa" id = "program1"> <strong>Lihat Profil</strong>  </a></center>

</div>
</div>
</div>




<div class = "col-md-2" style = "margin-left:150px;margin-right:100px;" >
<div class = "card" style = "padding-bottom:3px; height:500px; width:300px;">
<div class = "caption" style = "padding-left : 10px; padding-right:10px;">
<img src="assets/img/find_user.png" alt="text/css" >
<h5 style = "font-size:25px; margin-top:5px;" >  <strong>  <center>Riqy Rizqiandra </center> </strong> </h5>
<h6 style = "font-size:20px; margin-top:10px; margin-bottom:4px;color:red;"> <strong><center>Autodesk Inventor </center> </strong> </h6>
<h7 style = "font-size:15px;"> <center>Passion dan interest dalam mendesain teknik juga dapat menghasilkan pundi-pundi rupiah. Seperti yang dilakukan Riqy, Ia telah berhasil menyelesaikan beberapa proyek desain teknik berharga jutaan rupiah.</center> </h7>
<br>
<center><a style= "margin-bottom:5px;" href="ambil.php?id=<?php echo $bagian['id_program'] ?>" class = "btn btn-success btn-lg" name = "programa" id = "program1"> <strong> Lihat Profil </strong> </a></center>



<center></center>

</div>
</div>
</div>










<div class = "col-md-2" style = "margin-left:150px; margin-left:100px;" >
<div class = "card" style = "padding-bottom:3px; height:500px; width:300px;" >

<div class = "caption" style = "margin-left : 5px; margin-right:5px;">
<img src="assets/img/find_user.png" alt="text/css">
<h5 style = "font-size:25px; margin-top:5px;"> <strong><center>Ghifari Mustofar</center></strong> </h5>
<h6 style = "font-size:20px; margin-top:10px; margin-bottom:4px;color:red;"> <center>ANSYS FLuent</center> </h6>
<h7 style = "font-size:15px;"> <center>Kreatifitas dan keahlian dalam menguasai software ANSYS Fluent, membawanya berhasil dalam menjuarai kejuaraan International di Turki membawa nama harum Indonesia di kancah internasional.</center> </h7>
<br>  <br> 
<center> <a style= "margin-bottom:5px;" href="ambil.php?id=<?php echo $bagian['id_program'] ?>" class = "btn btn-success btn-lg" name = "programa" id = "program1"> <strong>  Lihat Profil </strong></a></center>

</div>
</div>
</div>


</center>

</div>
</div>


<br><br>








<div class="jumbotron" style = " min-height:600px;background-color:white;">
<div class = "row">

<div class = "col-lg-12"><br><br></h1></div>












<div class = "col-md-6" style = "margin-left:50px; padding-left:-30px;">
<img src="gambar/study1.jpg" alt="text/css">

</div>






<div class = "col-md-6" style ="background-color:#dc3545; margin-left:-100px; padding-left:10px; margin-right:20px; padding-right:20px;">

<center>
<div class = "nav-item margin-top:50px;" style = "size:50px;">

<div class = "fa fa-desktop fa-4x" style = "size:50px; margin-top:50px; color:white;"></div>
</div>

<ion-icon name="chatbubbles"></ion-icon>

</center>

 <center> <h3 style = " font-size:40px;  color:white"> <strong> Pembelajaran Dua Arah </strong></h3></center> 
<center> <h6 style = "color:white; font-size:20px; margin-top:10px;">Tidak hanya mendengarkan materi yang membosankan, kamu bisa bertanya kepada tentor sampai bisa. Kamu juga berhak untuk meminta konsultasi walau di luar jam kelas sampai kamu bisa.</h6> </center>






</div>



<div class = "w-100"></div>









<div class = "col-md-6" style ="background-color:#dc3545; margin-left:65px; padding-left:60px;width:200px;">


<center>
<div class = "nav-item margin-top:50px;" style = "size:50px;">

<div class = "fa fa-flask fa-5x" style = "size:50px; margin-top:50px;margin-right:150px;color:white;"></div>
</div>
</center>

 <center> <h3 style = " font-size:40px;  color:white; margin-top:20px; margin-left:-100px;"> <strong> Practice Makes Perfect </strong></h3></center> 
<center> <h6 style = "color:white; font-size:20px; margin-top:10px; margin-right:80px;">Untuk menjadi seorang ahli, butuh waktu sekitar 10.000 Jam untuk menekuni bidang tersebut. Didukung oleh tugas-tugas yang sebagian besar adalah praktik, menuntut kamu untuk terbiasa dengan environment software tersebut. Dalam waktu 2 minggu selama 4 kali pertemuan, kamu akan mampu menghasilkan desain teknik menggunakan software yang professional.</h6> </center>






</div>






<div class = "col-md-6" style = "margin-left:-75px;margin-right:-50px;">
<img src="gambar/library.jpg" alt="text/css" >

</div>


</div>
</div>




































































<div class = "content-wrapper">
<div class = "wrapper">
<div class = "container">
<div class = "col-lg-12">
<div class = "col-lg-12">
<section>
<center>
<h1> Ingin Mengetahui kontak kami ? Silakan Hubungi Kontak ini !</h1></center>
<br><br><br>

<div class = "nav-item margin-top:50px;" style = "size:50px;">

<div class = "nav-item" style = "size:50px;">
<center>
 <h2> <div class = "fa fa-whatsapp fa-4x" style = "size:100%;color:green;"> 087-847-972-064</div></h2></center>
</div>


</div>




<br><br><br><br><br><br>






</section>
</div></div> </div>






</div>



</div>


















  <!-- Site footer -->
  <footer class="site-footer">
      <div class="container">
        <div class="row">





        <div class = "col-lg-12 col-md-12" style = "margin-bottom:20px;">
    
        <center><h2 style = "color:white;"> AYO, MULAILAH BANGUN KARIR ANDA DI SINI </h2></center> 
    </div>










          <div class="col-sm-12 col-md-6">
            <h6>About</h6>
            <p class="text-justify">MechTech Merupakan salah satu Platform pembelajaran untuk persiapan di dunia industri yang sangat disarankan.</p>
          </div>

          <div class="col-xs-6 col-md-3">
            <h6>Kategori</h6>
            <ul class="footer-links">
              <li><a href="http://scanfcode.com/category/c-language/"></a></li>
              <li><a href="http://scanfcode.com/category/front-end-development/">Solidworks</a></li>
              <li><a href="http://scanfcode.com/category/back-end-development/">Matlab</a></li>
              <li><a href="http://scanfcode.com/category/java-programming-language/">AutoDesk Inventor</a></li>
              <li><a href="http://scanfcode.com/category/android/"></a></li>
              <li><a href="http://scanfcode.com/category/templates/"></a></li>
            </ul>
          </div>

          <div class="col-xs-6 col-md-3">
            <h6>Quick Links</h6>
            <ul class="footer-links">
              <li><a href="http://scanfcode.com/about/">About Us</a></li>
              <li><a href="http://scanfcode.com/contact/">Contact Us</a></li>
              <li><a href="http://scanfcode.com/contribute-at-scanfcode/">Contribute</a></li>
              <li><a href="http://scanfcode.com/privacy-policy/">Privacy Policy</a></li>
              <li><a href="http://scanfcode.com/sitemap/">Sitemap</a></li>
            </ul>
          </div>
        </div>
        <hr>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; <?php echo date("Y")?> Indonesian
         <a href="#">MechTech</a>.
            </p>
          </div>



          <div class="col-md-4 col-sm-6 col-xs-12">
            <ul class="social-icons">
              <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a class="dribbble" href="#"><i class="fa fa-instagram"></i></a></li>
              <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>   
            </ul>
          </div>
        </div>
      </div>
</footer>
















    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script>
    function showTime(){
    var date = new Date();
    var h = date.getHours(); // 0 - 23
    var m = date.getMinutes(); // 0 - 59
    var s = date.getSeconds(); // 0 - 59
    var session = "AM";
    
    if(h == 0){
        h = 12;
    }
    
    if(h > 12){
        h = h - 12;
        session = "PM";
    }
    
    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;
    
    var time = h + ":" + m + ":" + s + " " + session;
    document.getElementById("MyClockDisplay").innerText = time;
    document.getElementById("MyClockDisplay").textContent = time;
    
    setTimeout(showTime, 1000);
    
}

showTime();

</script>

<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
    document.getElementByClassName("navbar").style.padding = "30px 10px";
    document.getElementById("logo").style.fontSize = "25px";
  } else {
    document.getElementByClassName("navbar").style.padding = "80px 10px";
    document.getElementById("logo").style.fontSize = "35px";
  }
}


</script>


</body>
</html>
